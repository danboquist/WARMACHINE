#!/bin/sh
#This script collects system information
#for use by SAP support
# Written by Doug Bonomo of SAP Support
#Dec 4 2017 update: Added additional tests for ldd, crystal specific.  Also removed the core file overview since these days most people have these turned off to save disk space, or, send them to a different file system.
SURVEY_VERBOSE=1
clear
CARRIAGE=`echo "\0015"`
SURVEY_MESSAGE="Starting..."; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
SURVEY_MESSAGE="Please be sure you are using the most current version of this script"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
SURVEY_MESSAGE="It can be obtained from SAP knowledge base article 1681036"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
SURVEY_FILESIZE=0
SURVEY_GENERAL_PRODUCT=0
SURVEY_GETLOGS=0 
PRODUCT_IS_INSTALLED=0
SURVEY_WDEPLOY_LOGS_FOUND=0
SURVEY_OS_PACKAGELIST=""
SURVEY_NAV_PACKAGELIST=""
SURVEY_ORACLE_TEST=0
SURVEY_ORACLE32_TEST=0
VER="DEC-4-2017"
MYUID=`id|awk '{print $1}'|awk -F\( '{print $1}'|awk -F\= '{print $2}'`
SURVEY_MESSAGE="Collecting UserID Info"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
if [ $MYUID = "0" ]; then
   echo "Script version $VER"
   echo "Please run this script as the owner of the "
   echo "SAP Business Objects installation, ideally "
   echo "from the bobje or sap_bobj folder"
   exit
fi

### Is the product installed in this folder?
#./ccm.config
SURVEY_SOURCE="ccm.config"
if [ -s $SURVEY_SOURCE ]; then
   PRODUCT_IS_INSTALLED=1

   #################################
   ## Is the script being run properly?
   SURVEY_CCM_OWNER=`ls -ld | awk '{print $3}'`
   SURVEY_USERNAME=`id|awk '{print $1}'|awk -F\( '{print $2}'|awk -F\) '{print $1}'`
   if [ $SURVEY_CCM_OWNER = $SURVEY_USERNAME ]; then
      echo "User is $SURVEY_USERNAME, ccm.config is owned by $SURVEY_CCM_OWNER, proceeding"
   else
      SURVEY_1_RESPONSE_YN=
      echo "It appears the product is installed in the current directory ( "`pwd`" ), do you wish to troubleshoot this installation? (Yes / No)"
      read SURVEY_1_RESPONSE_YN
      case $SURVEY_1_RESPONSE_YN in
         [Yy]|[Yy][Ee][Ss])
            echo "Please run this script as the user: $SURVEY_CCM_OWNER"
            echo "For more information please refer to the knowledge base article (1681036) this script was downloaded from."
            exit
            ;;
         [Nn]|[Nn][Oo])
            echo "Please run this script from the $SURVEY_USERNAME user's home directory, or, in the proper installation directory."
            echo "For more information please refer to the knowledge base article (1681036) this script was downloaded from."
            exit
            ;;
         *) exit 3;;
      esac
   fi
   ## End script execution testing
   #################################

   ### Want logs with that?
   SURVEY_2_RESPONSE_YN=
   echo "Would you like to include the installation logs for the product with the survey output? (Yes / No)"
   read SURVEY_2_RESPONSE_YN
   case $SURVEY_2_RESPONSE_YN in
      [Yy]|[Yy][Ee][Ss])
         echo "Thank you, logs will be included in the resulting output"
         SURVEY_GETLOGS=1
         ;;
      [Nn]|[Nn][Oo])
         echo "Thank you, logs will not be included in the resulting output"
         SURVEY_GETLOGS=0
         ;;
      *) exit 3;;
   esac
   ### End log request
else
   while true; do
   SURVEY_3_RESPONSE_YN=
   echo "It is recommended that you run this script from the product installation folder."
   echo ".../sap_bobj or .../bobje for example."
   echo "If this is not possible, please proceed.  Otherwise, answer no and move the script to that location and run again."
   echo "Continue from current location? (yes or no)"
   read SURVEY_3_RESPONSE_YN
   case $SURVEY_3_RESPONSE_YN in
      [Yy]|[Yy][Ee][Ss]) 
         echo "Continuing from this directory."
         break
         ;;
      [Nn]|[Nn][Oo])
         echo "For best results, please run this script from the sap_bobj or bobje folder as appropriate to your software version."
         echo "Exiting the script, for full instructions on using this script please refer to the kbase it was retrieved from, # 1681036."
         exit
         ;;
      *) clear
         echo "Please answer Y or N (yes or no)"
         ;;
   esac
   done
fi


SURVEY_MEMORY_INSTALLED=0
SURVEY_CENTOS_CHECK=0
SURVEY_FILESIZE=0

#declare -i SURVEY_MEMORY_INSTALLED
#declare -i SURVEY_CENTOS_CHECK
#declare -i SURVEY_FILESIZE

UNAME=`uname -s`
SURVEY_MESSAGE="Determining OS"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
case $UNAME in
        HP-UX)
                OS=ux11
                HOSTNAME=`hostname -s`
                ;;
        Linux)
                OS=linux
                HOSTNAME=`hostname -s`

                # BI4 DB2 prep work
				SURVEY_UID=`id -u`
				SURVEY_UNAME=`id -un`
				SURVEY_PGID=`id -g`
				SURVEY_PGNAME=`id -gn`
				tmptest=`mount|grep /tmp|grep noexec | wc -l`
				tmptestout=`mount|grep /tmp|grep noexec`

                SURVEY_MESSAGE="Determining Hostname"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_MAX_PROC=`ulimit -u`

                SURVEY_CPU_COUNT=`cat /proc/cpuinfo |grep "model name"|wc -l`
                SURVEY_MESSAGE="Determining CPU Count"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_CPU_INFO=`cat /proc/cpuinfo |grep "model name"|awk -F: '{print $2}'|sed s/^\ //g|sort -u`
                SURVEY_MESSAGE="Determining CPU Type"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_MEMORY_INSTALLED=`grep MemTotal /proc/meminfo|awk '{print $2}'`
                #SURVEY_MEMORY_INSTALLED=`expr $SURVEY_MEMORY_INSTALLED \* 1`
                SURVEY_MESSAGE="Determining System Memory"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_MEMORY_INSTALLED=`expr $SURVEY_MEMORY_INSTALLED / 1021000`

                SURVEY_SYSTEM_UPTIME=`/usr/bin/uptime`
                SURVEY_MESSAGE="Determining System Uptime"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_FILESURVEY_SYSTEM_DF=`/bin/df -Ph | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting File System Consumption"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_FILESURVEY_SYSTEM_MOUNTS=`/bin/mount | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting File System Mount Points"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_NETWORKING_NETSTAT=`/bin/netstat -anpee 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Network Activity (netstat -anpee)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                   
                SURVEY_NETWORKING_NSLOOKUP=`nslookup $HOSTNAME`
                SURVEY_MESSAGE="Collecting nslookup information (nslookup `hostname`)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_NETWORKING_STATS=`/bin/netstat -s 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Networking Statistics (netstat -s)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_NETWORKING_CONFIG=`/sbin/ifconfig -a 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Network Config (ifconfig -a)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_DETAILS_USERNAME=`id -un`
                SURVEY_DETAILS_OPENFILES=`/usr/sbin/lsof -u $SURVEY_DETAILS_USERNAME 2>/dev/null | wc -l`

                SURVEY_MESSAGE="Counting the number of open files by this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_OPENFILES_COUNT=`lsof -u $SURVEY_DETAILS_USERNAME 2>/dev/null|wc -l`

                SURVEY_MESSAGE="Counting the number of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES_COUNT=`ps | wc -l`

                SURVEY_MESSAGE="Collecting the list of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES=`ps -ef | grep $USER | awk 'sub("$", "\r")'`

                SURVEY_KERNEL_LIMITS=`ipcs -l | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the kernel limits for this system"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_KERNEL_USAGE=`ipcs | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the kernel activity for this system"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_OS_PACKAGELIST=`rpm -qa | sort | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the packages installed to this system (rpm -qa)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_CENTOS_CHECK=`/bin/rpm -qa --qf '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH};%{DISTRIBUTION}\n'|grep -i centos|wc -l`
                #SURVEY_CENTOS_CHECK=`expr $SURVEY_CENTOS_CHECK \* 1`
                #SURVEY_CENTOS_CHECK=`/bin/rpm -qa --qf '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH};%{DISTRIBUTION}\n'|grep -i "Red Hat"|wc -l`

		SURVEY_SOURCE="$ORACLE_HOME/lib/libclntsh.so"
                echo "Checking for Oracle client"
				if [ -e $SURVEY_SOURCE ]; then
					# Oracle home seems to be set
					# determine if this is 32 or 64 bit
					SURVEY_ORACLE_TEST=1
					SURVEY_ORACLE_CLIENT_FILES=`ls -l $ORACLE_HOME/*|awk 'sub("$", "\r")'`
					SURVEY_ORACLE_CLIENT_TEST1=`file -L $ORACLE_HOME/lib/libclntsh.so`
				fi

				if [ -e $ORACLE_HOME/lib32/libclntsh.so ]; then
                   # Oracle home seems to be set and this is a 64bit install
                   SURVEY_ORACLE_CLIENT_TEST2=`file -L $ORACLE_HOME/lib32/libclntsh.so`
                fi


                if [ -s /usr/lib/libexpat.so.1 ]; then
                   SURVEY_MISC_LIBEXPAT32="<li><font color=#green>Subversion Dependency Check - PASS: /usr/lib/libexpat.so.1 exists</font>"
                else
                   if [ -s /usr/lib/libexpat.so ]; then
                      SURVEY_MISC_LIBEXPAT32="<li><font color=#red>Subversion Dependency Check - FAIL: libexpat.so.1 not found in /usr/lib, correct with the following command (as root): ln -s /usr/lib/libexpat.so /usr/lib/libexpat.so.1</font>"
                   else
                      SURVEY_MISC_LIBEXPAT32="<li><font color=#red>Subversion Dependency Check - FAIL: 32bit libexpat.so is missing.  Please have your system admin correct this.</font>";
                   fi
                 fi
                 if [ -s /usr/lib64/libexpat.so.1 ]; then
                    SURVEY_MISC_LIBEXPAT64="<li><font color=#green>Subversion Dependency Check - PASS: /usr/lib64/libexpat.so.1 exists</font>"
                 else
                    if [ -s /usr/lib64/libexpat.so ]; then
                       SURVEY_MISC_LIBEXPAT64="<li><font color=#red>Subversion Dependency Check - FAIL: libexpat.so.1 not found in /usr/lib64, correct with the following command (as root): ln -s /usr/lib/libexpat.so /usr/lib/libexpat.so.1</font>"
                    else
                       SURVEY_MISC_LIBEXPAT64="<li><font color=#red>Subversion Dependency Check - FAIL: 64bit libexpat.so is missing.  Please have your system admin correct this.</font>";
                    fi
                 fi
                ;;
        SunOS)
                OS=sunos5

				# BI4 DB2 Prep work
                SURVEY_UID=`id |awk -F\( '{print $1}'|sed s/uid=//`
                SURVEY_UNAME=`id |awk -F\( '{print $2}'|sed s/\).*//`
                SURVEY_PGID=`id |awk -F\) '{print $2}'|sed s/\(.*//|sed s/.*gid.//`
                SURVEY_PGNAME=`id |awk -F\( '{print $3}'|sed s/\).*//`
				##############################

                # ulimit -u not supported on solaris, so assuming unlimited for now
                SURVEY_MAX_PROC="unlimited"

		HOSTNAME=`hostname|awk -F\. '{print $1}'`
                SURVEY_MESSAGE="Determining Hostname"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_CPU_COUNT=`/usr/sbin/psrinfo -v | grep Status | wc -l`
                SURVEY_MESSAGE="Determining CPU Count"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		#The sparcv9 processor operates at 1167 MHz
                SURVEY_CPU_INFO=`psrinfo -v|grep operates|sort -u|sed s/The\ //|sed s/processor\ operates\ at\ //|sed s/,//`
                SURVEY_MESSAGE="Determining CPU Type"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_MEMORY_INSTALLED=`prtdiag | grep "Memory size"|awk '{print $3" "$4}'`
                SURVEY_MESSAGE="Determining System Memory"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_SYSTEM_UPTIME=`/usr/bin/uptime`
                SURVEY_MESSAGE="Determining System Uptime"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_FILESURVEY_SYSTEM_DF=`/usr/bin/df -h | sed s/$/${CARRIAGE}/`
                #SURVEY_FILESURVEY_SYSTEM_DF=`/usr/bin/df -h | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting File System Consumption"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_FILESURVEY_SYSTEM_MOUNTS=`/usr/sbin/mount |sed s/$/${CARRIAGE}/`
                #SURVEY_FILESURVEY_SYSTEM_MOUNTS=`/usr/sbin/mount | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting File System Mount Points"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_NETWORKING_NETSTAT=`/usr/bin/netstat -an 2>/dev/null | sed s/$/${CARRIAGE}/`
                #SURVEY_NETWORKING_NETSTAT=`/usr/bin/netstat -an 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Network Activity (netstat -anpee)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_NETWORKING_STATS=`/usr/bin/netstat -i 2>/dev/null | sed s/$/${CARRIAGE}/`
                #SURVEY_NETWORKING_STATS=`/usr/bin/netstat -i 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Networking Statistics (netstat -s)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_NETWORKING_CONFIG=`/usr/sbin/ifconfig -a 2>/dev/null | sed s/$/${CARRIAGE}/`
                #SURVEY_NETWORKING_CONFIG=`/usr/sbin/ifconfig -a 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Network Config (ifconfig -a)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_DETAILS_USERNAME=$USER
                if [ -x /usr/sbin/lsof ]; then
                   SURVEY_MESSAGE="Collecting the list of openfiles for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                   SURVEY_DETAILS_OPENFILES=`/usr/sbin/lsof -u $SURVEY_DETAILS_USERNAME 2>/dev/null | wc -l`

                   SURVEY_MESSAGE="Counting the number of open files by this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                   SURVEY_DETAILS_OPENFILES_COUNT=`lsof -u $SURVEY_DETAILS_USERNAME 2>/dev/null|wc -l`
                else
                   SURVEY_DETAILS_OPENFILES="lsof not available"
                   SURVEY_DETAILS_OPENFILES_COUNT="unavailable"
		fi
				
       		echo "Checking for Oracle client"

		if [ "x"$ORACLE_HOME"x" != "xx" ]; then
			if [ -d $ORACLE_HOME ]; then
				# Oracle home seems to be set
				# determine if this is 32 or 64 bit
				SURVEY_ORACLE_TEST=1
				SURVEY_ORACLE_CLIENT_FILES=`ls -l $ORACLE_HOME/*|sed s/$/${CARRIAGE}/`
				SURVEY_ORACLE_CLIENT_TEST1=`file $ORACLE_HOME/lib/libclntsh.so`

				if [ -f $ORACLE_HOME/lib32/libclntsh.so ]; then
       					# Oracle home seems to be set and this is a 64bit install
               	    			SURVEY_ORACLE_CLIENT_TEST2=`file $ORACLE_HOME/lib32/libclntsh.so`
               	 		fi
				if [ "x"$ORACLE_HOME32"x" != "xx" ]; then
					if [ -f $ORACLE_HOME32/lib/libclntsh.so ]; then
                				# Oracle home 32 seems to be set
						SURVEY_ORACLE32_TEST=1
						SURVEY_ORACLE_CLIENT_FILES2=`ls -l $ORACLE_HOME32/*|sed s/$/${CARRIAGE}/`
                				SURVEY_ORACLE_CLIENT_TEST3=`file $ORACLE_HOME32/lib/libclntsh.so`
                			fi
				fi
			fi
		fi
                SURVEY_OS_PACKAGELIST=`/usr/bin/pkginfo | sort | sed s/$/${CARRIAGE}/`
                SURVEY_MESSAGE="Collecting the packages installed to this system (pkginfo)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_MESSAGE="Counting the number of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES_COUNT=`ps | wc -l`

                SURVEY_MESSAGE="Collecting the list of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES=`ps -u $SURVEY_DETAILS_USERNAME -f | sed s/$/${CARRIAGE}/`
                #SURVEY_DETAILS_RUNNING_PROCESSES=`ps -u $SURVEY_DETAILS_USERNAME -f |awk 'sub("$", "\r")'`

                SURVEY_KERNEL_LIMITS=`ipcs -b | sed s/$/${CARRIAGE}/`
                #SURVEY_KERNEL_LIMITS=`ipcs -b | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the kernel limits for this system"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_KERNEL_USAGE=`ipcs | sed s/$/${CARRIAGE}/`
                #SURVEY_KERNEL_USAGE=`ipcs | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the kernel activity for this system"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_OS_PATCHES=`/usr/bin/showrev -p | sed s/$/${CARRIAGE}/`
                SURVEY_MESSAGE="Collecting the installed fixes (showrev -p) list"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                ;;
        AIX)
                OS=aix4
                HOSTNAME=`hostname -s`
                # ulimit -u not supported on aix, so assuming unlimited for now
                SURVEY_MAX_PROC="unlimited"
                SURVEY_UNAME=`id -un`

                # BI4 DB2 Prep work
                SURVEY_UID=`id |awk -F\( '{print $1}'|sed s/uid=//`
                SURVEY_UNAME=`id |awk -F\( '{print $2}'|sed s/\).*//`
                SURVEY_PGID=`id |awk -F\) '{print $2}'|sed s/\(.*//|sed s/.*gid.//`
                SURVEY_PGNAME=`id |awk -F\( '{print $3}'|sed s/\).*//`
                ##############################


                SURVEY_UID=`id -u`
                SURVEY_FILESURVEY_SYSTEM_MOUNTS=`/usr/sbin/mount 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting File System Mount Points"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_FILESURVEY_SYSTEM_DF=`/usr/bin/df -g | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting File System Consumption"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_SYSTEM_UPTIME=`/usr/bin/uptime`
                SURVEY_MESSAGE="Determining System Uptime"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_CPU_COUNT=`lparstat -i | grep "Online Virtual CPUs"| awk -F: '{print $2}'|sed s/\ //g`
		SURVEY_CPU_COUNT=$SURVEY_CPU_COUNT" (see lparstat)"
                SURVEY_MESSAGE="Determining CPU Count"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
    
                SURVEY_CPU_INFO="See lparstat for details"

		SURVEY_MEMORY_INSTALLED=`lparstat -i | grep "Online Memory" | awk -F: '{print $2}'|sed s/\ //g`
		#SURVEY_MEMORY_INSTALLED=`expr $SURVEY_MEMORY_INSTALLED \* 1`
		SURVEY_MEMORY_INSTALLED=$SURVEY_MEMORY_INSTALLED" (See lparstat details)"
                SURVEY_MESSAGE="Determining System Memory"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_NETWORKING_NETSTAT=`/usr/bin/netstat -an 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Network Activity (lsof -i -n -P)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_NETWORKING_STATS=`/usr/bin/netstat -s 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Networking Statistics (netstat -s)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_NETWORKING_CONFIG=`/etc/ifconfig -a 2>/dev/null | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting Network Config (ifconfig -a)"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_DETAILS_USERNAME=`id -un`

                SURVEY_DETAILS_OPENFILES=`/usr/sbin/lsof -u $SURVEY_DETAILS_USERNAME 2>/dev/null`
		SURVEY_MESSAGE="Collecting the list of open files by this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_DETAILS_OPENFILES_COUNT=`lsof -u $SURVEY_DETAILS_USERNAME 2>/dev/null|wc -l`
		SURVEY_MESSAGE="Counting the number of open files by this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		SURVEY_MESSAGE="Counting the number of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES_COUNT=`ps |grep -v grep | grep -v PID | wc -l`


		SURVEY_MESSAGE="Collecting the list of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES=`ps -u $SURVEY_DETAILS_USERNAME -f | awk 'sub("$", "\r")'`

		SURVEY_MESSAGE="Collecting the list of running processes for this user"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi
                SURVEY_DETAILS_RUNNING_PROCESSES_LIST="<pre>"`ps -U $SURVEY_DETAILS_USERNAME -f | awk 'sub("$", "\r")'`"</pre>"

		SURVEY_KERNEL_LIMITS="Not supported on AIX... yet"

		SURVEY_KERNEL_USAGE=`ipcs | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the kernel activity for this system"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_OS_PATCHES=`instfix -i | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the installed fixes (instfix -i) list"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_OS_PACKAGELIST=`lslpp -lc | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the installed packages (lslpp -lc) list"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

                SURVEY_OS_CPLUSPLUS=`lslpp -lc | grep xlC | awk 'sub("$", "\r")'`
                SURVEY_MESSAGE="Collecting the C++ information (lslpp -lc|grep xlC) list"; if [ $SURVEY_VERBOSE = 1 ]; then echo $SURVEY_MESSAGE; fi

		echo "Checking for Oracle client"
                if [ "x"$ORACLE_HOME"x" != "xx" ]; then
                        if [ -d $ORACLE_HOME ]; then
                                # Oracle home seems to be set
                                # determine if this is 32 or 64 bit
                                SURVEY_ORACLE_TEST=1
                                SURVEY_ORACLE_CLIENT_FILES=`ls -l $ORACLE_HOME/*|awk 'sub("$", "\r")'`
                                SURVEY_ORACLE_CLIENT_TEST1=`file $ORACLE_HOME/lib/libclntsh.so`

                                if [ -f $ORACLE_HOME/lib32/libclntsh.so ]; then
                                        # Oracle home seems to be set and this is a 64bit install
                                        SURVEY_ORACLE_CLIENT_TEST2=`file $ORACLE_HOME/lib32/libclntsh.so`
                                fi
                                if [ "x"$ORACLE_HOME32"x" != "xx" ]; then
                                        if [ -f $ORACLE_HOME32/lib/libclntsh.so ]; then
                                                # Oracle home 32 seems to be set
                                                SURVEY_ORACLE32_TEST=1
                                                SURVEY_ORACLE_CLIENT_FILES2=`ls -l $ORACLE_HOME32/*|awk 'sub("$", "\r")'`
                                                SURVEY_ORACLE_CLIENT_TEST3=`file $ORACLE_HOME32/lib/libclntsh.so`
                                        fi
                                fi
                        fi
                fi

                ;;
        Darwin)
                ;;
        *)
                echo "Unknown platform $UNAME detected \n"
esac

### Post collection calculations
### End Post collection calculations

SURVEY_OUTDIR=`date '+survey-%m%d%y_%H%M%S'`"-"$HOSTNAME

SURVEY_STYLE="<style>table { font-size: 14px; } </style>"

SURVEY_LOGSFOUND=0
mkdir $SURVEY_OUTDIR
mkdir $SURVEY_OUTDIR/content
mkdir -p $SURVEY_OUTDIR/files

#if [ -s $SURVEY_SOURCE ]; then
#   # Core file overview
#   COREFILECOUNT=0
#   #declare -i COREFILECOUNT
#   COREFILECOUNT=`ls -l core* 2>/dev/null|wc -l`
#   if [ $COREFILECOUNT -gt 0 ]; then
#      CORELIST=`ls -l core*| sed s/$/\\r\\n/`
#      CORESTUDY=`ls -1 core*|awk '{print "file "$0}'|sh| sed s/$/\\r\\n/`
#
#      SURVEY_TARGETLABEL="core files found"
#      SURVEY_TARGETFILE="corefiles.txt"
#      SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
#      echo "List of core files found in "`pwd` > $SURVEY_TARGET
#      echo $CORELIST >> $SURVEY_TARGET
#      echo "" >> $SURVEY_TARGET
#      echo "What generated each core file" >> $SURVEY_TARGET
#      echo $CORESTUDY >> $SURVEY_TARGET
#      SURVEY_NAV_COREFILES="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
#   fi
# End core file overview
#####
#fi


########################
## LOGFILE COLLECTION ##
if [ $SURVEY_GETLOGS = 1 ]; then
   if [ -d ../InstallData/logs ]; then
      mkdir -p $SURVEY_OUTDIR/InstallLogs
      cp -R ../InstallData/logs/* $SURVEY_OUTDIR/InstallLogs
      SURVEY_LOGSFOUND=1
   fi

   if [ $SURVEY_LOGSFOUND = 0 ]; then
      if [ -d ../setup/logs ]; then
         mkdir -p $SURVEY_OUTDIR/InstallLogs
         cp -R ../setup/logs/* $SURVEY_OUTDIR/InstallLogs
         SURVEY_LOGSFOUND=1
      fi
   fi

   if [ $SURVEY_LOGSFOUND = 1 ]; then
      SURVEY_NAV_INSTALLLOGS="<li><a href=../InstallLogs target=main>Install Logs</a>"
   fi

   if [ -d enterprise_xi40/wdeploy/logs ]; then
      mkdir -p $SURVEY_OUTDIR/wdeploy/logs
      cp enterprise_xi40/wdeploy/logs/* $SURVEY_OUTDIR/wdeploy/logs
      SURVEY_WDEPLOY_LOGS_FOUND=1
   fi

   if [ -s ../deployment/workdir/wdeploy.log ]; then
      mkdir -p $SURVEY_OUTDIR/wdeploy/logs
      cp ../deployment/workdir/wdeploy.log $SURVEY_OUTDIR/wdeploy/logs
      SURVEY_WDEPLOY_LOGS_FOUND=1
   fi
   
   if [ $SURVEY_WDEPLOY_LOGS_FOUND = 1 ]; then
      SURVEY_NAV_WDEPLOYLOGS="<li><a href=../wdeploy/logs target=main>Wdeploy Logs</a>"
   fi

   #wdeploy config files
   if [ -d "enterprise_xi40/wdeploy/conf" ]; then
   mkdir -p $SURVEY_OUTDIR/wdeploy/conf
   cp -R enterprise_xi40/wdeploy/conf/* $SURVEY_OUTDIR/wdeploy/conf
   SURVEY_WDEPLOY_CONF_FOUND=1
   # end wdeploy config files
   fi

   if [ -d "../deployment" ]; then
   mkdir -p $SURVEY_OUTDIR/wdeploy/conf
   cp ../deployment/config.* $SURVEY_OUTDIR/wdeploy/conf
   SURVEY_WDEPLOY_CONF_FOUND=1
   # end wdeploy config files
   fi

   if [ $SURVEY_WDEPLOY_CONF_FOUND = 1 ]; then
      SURVEY_NAV_WDEPLOYCONFS="<li><a href=../wdeploy/conf target=main>Wdeploy Configs</a>"
   fi
fi

## END LOG FILE COLLECTION ##
#############################

if [ $SURVEY_ORACLE_TEST = '1' ]; then 
   SURVEY_OUTFILE="$SURVEY_OUTDIR/files/oracletests.txt"
   echo "Oracle tests.  For BI4.x you need 64bit client libs.  For XI31 you need 32bit." >  $SURVEY_OUTFILE
   echo "" >> $SURVEY_OUTFILE
   echo "file -L \$ORACLE_HOME/lib/libclntsh.so" >> $SURVEY_OUTFILE
   echo $SURVEY_ORACLE_CLIENT_TEST1 >> $SURVEY_OUTFILE
   echo "" >> $SURVEY_OUTFILE
   echo "file -L \$ORACLE_HOME/lib32/libclntsh.so (might not exist)" >> $SURVEY_OUTFILE
   echo $SURVEY_ORACLE_CLIENT_TEST2 >> $SURVEY_OUTFILE
   echo "file -L \$ORACLE_HOME32/lib/libclntsh.so (might not exist)" >> $SURVEY_OUTFILE
   echo $SURVEY_ORACLE_CLIENT_TEST3 >> $SURVEY_OUTFILE
   echo "" >> $SURVEY_OUTFILE
   echo "ls -l \$ORACLE_HOME/*" >> $SURVEY_OUTFILE
   echo $SURVEY_ORACLE_CLIENT_FILES >> $SURVEY_OUTFILE
   SURVEY_NAV_ORACLE="<li><a href=../files/oracletests.txt target=main>Oracle details</a>"
   # This does the ORACLE_HOME32 stuff
   SURVEY_OUTFILE="$SURVEY_OUTDIR/files/oracle32tests.txt"
   echo $SURVEY_ORACLE_CLIENT_FILES2 >> $SURVEY_OUTFILE
   SURVEY_NAV_ORACLE32="<li><a href=../files/oracle32tests.txt target=main>Oracle32 details</a>"
fi

#############################
## Begin SLD file collection ##
if [ -d enterprise_xi40/java/lib/bobj-sld-ds ]; then
   mkdir -p $SURVEY_OUTDIR/sldfiles
   cp -R enterprise_xi40/java/lib/bobj-sld-ds/*xml $SURVEY_OUTDIR/sldfiles
   SURVEY_NAV_SLDFILES="<li><a href=../sldfiles target=main>SLD Files</a>"
fi
## End SLD file collection ##
#############################

if [ $SURVEY_CENTOS_CHECK -gt 0 ]; then
   SURVEY_CENTOS_ALERT="<tr><td><b><font color=red>CENTOS Alert</font></b></td><td>CentOS is not supported, please click <a href=../files/CENTOS.txt target=main>here</a> to see the reason for this alert to confirm</td></tr>"
rpm -qa --qf '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH};%{DISTRIBUTION}\n' | column -ts\;|awk 'sub("$", "\r")' > $SURVEY_OUTDIR/files/CENTOS.txt
fi

##################################
## Begin config file Collection ##
# Nav page should maintain a grouping of some kind, so that you can easily tell where you are.  Example:
# tomcat
# -- bin/catalina.sh
# -- bin/setenv.sh
# -- conf/server.xml
# -- logs (ls -1tr | tail -n 10)

#./ccm.config (this was moved to the top of the script as a test of whether the product is installed)
SURVEY_SOURCE="$HOME/.businessobjects/clusterinfo.1400.properties"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="BI4 clusterinfo"
   SURVEY_TARGETFILE="cluster1400.txt"
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_BI4CLUSTERFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

SURVEY_SOURCE="$HOME/.businessobjects/clusterinfo.1200.properties"
if [ -s $SURVEY_SOURCE ]; then
   echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="XI31 clusterinfo"
   SURVEY_TARGETFILE="cluster1200.txt"
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_XI31CLUSTERFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

SURVEY_SOURCE="$HOME/.businessobjects"
SURVEY_CLUSTERFILECOUNT=0
if [ -d "$HOME/.businessobjects" ]; then
   echo "Counting clusterinfo files"
   SURVEY_CLUSTERFILECOUNT=`ls -l $HOME/.businessobjects/|grep clusterinfo|wc -l`
fi

# get a listing of the packages folder, if it exists

#./ccm.config (this was moved to the top of the script as a test of whether the product is installed)
SURVEY_SOURCE="ccm.config"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="ccm.config"
   SURVEY_TARGETFILE="ccm.config.txt"
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_CCMCONFIG="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#/etc/nsswitch.conf
SURVEY_SOURCE="/etc/nsswitch.conf"
if [ -s $SURVEY_SOURCE ]; then
   echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL=/etc/nsswitch.conf
   SURVEY_TARGETFILE=nsswitch.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   echo "" >> $SURVEY_TARGET
   cat $SURVEY_SOURCE >> $SURVEY_TARGET
   SURVEY_NAV_NSSWITCHFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

# Locale
# This output should go to the system overview page
if [ "x$LC_ALL" = "x" ]; then
   # LC_ALL not set
   SURVEY_MAIN_LOCALE="<font color=red>LC_ALL not set, please set to a valid locale per the supported platforms guide</font>"
   else
   # LC_ALL is set so lets see if the value exists in the installed locale list
   SURVEY_TEMP_LCALL=`locale -a | grep $LC_ALL`
   if [ $SURVEY_TEMP_LCALL = $LC_ALL ]; then
      # LC_ALL value is an installed locale
      SURVEY_MAIN_LOCALE="<font color=green>LC_ALL set to $LC_ALL which is an installed locale</font>"
   else
      SURVEY_MAIN_LOCALE="<font color=red>LC_ALL set to $LC_ALL which is NOT an installed locale</font>"
   fi
fi

#pull whats installed
SURVEY_SOURCE="../InstallData/inventory.txt"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="../InstallData/inventory.txt"
   SURVEY_TARGETFILE=inventory.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_INVENTORY="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   SURVEY_GENERAL_PRODUCT="BI4"
fi
SURVEY_SOURCE="../setup/ProductID.txt"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="../setup/ProductID.txt"
   SURVEY_TARGETFILE=ProductID.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_INVENTORY="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   SURVEY_GENERAL_PRODUCT="XI3x"
fi

SURVEY_SOURCE="$HOME/.profile"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="~/.profile"
   SURVEY_TARGETFILE=Profile.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_PROFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

SURVEY_SOURCE="$HOME/.bash_profile"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="~/.bash_profile"
   SURVEY_TARGETFILE=BASH_Profile.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_BASH_PROFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#/etc/resolv.conf
SURVEY_SOURCE="/etc/resolv.conf"
echo "Collecting $SURVEY_SOURCE"
if [ -s $SURVEY_SOURCE ]; then
   SURVEY_TARGETLABEL=/etc/resolv.conf
   SURVEY_TARGETFILE=resolv.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   echo "" >> $SURVEY_TARGET
   cat $SURVEY_SOURCE >> $SURVEY_TARGET
   SURVEY_NAV_RESOLVFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#/etc/hosts
SURVEY_SOURCE="/etc/hosts"
echo "Collecting $SURVEY_SOURCE"
if [ -s $SURVEY_SOURCE ]; then
   SURVEY_TARGETLABEL=/etc/hosts
   SURVEY_TARGETFILE=hosts.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   echo "It is critical that any given hostname resovle to one and only 1 ip address, hosts file is below:" >> $SURVEY_TARGET
   echo "" >> $SURVEY_TARGET
   cat $SURVEY_SOURCE >> $SURVEY_TARGET
   SURVEY_NAV_HOSTSFILE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#./tomcat/conf/server.xml
SURVEY_SOURCE="tomcat/conf/server.xml"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL=./tomcat/conf/server.xml
   SURVEY_TARGETFILE=server.xml.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_SERVERXML="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#./tomcat/bin/catalina.sh
SURVEY_SOURCE="tomcat/bin/catalina.sh"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL=./tomcat/bin/catalina.sh
   SURVEY_TARGETFILE=catalina.sh.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_CATALINASH="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#./tomcat/bin/setenv.sh
SURVEY_SOURCE="tomcat/bin/setenv.sh"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL=./tomcat/bin/setenv.sh
   SURVEY_TARGETFILE=setenv.sh.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_SETENVSH="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

#./tomcat/bin/bobjenv.sh
SURVEY_SOURCE="tomcat/bin/bobjenv.sh"
echo "Collecting $SURVEY_SOURCE"
SURVEY_TARGETLABEL=./tomcat/bin/bobjenv.sh
SURVEY_TARGETFILE=bobjenv.sh.txt
SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
if [ -s $SURVEY_SOURCE ]; then
   cp $SURVEY_SOURCE $SURVEY_TARGET
else
   echo $SURVEY_SOURCE" was not found on this host" > $SURVEY_TARGET
fi
SURVEY_NAV_BOBJENVSH="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

#./setup/env.sh
SURVEY_SOURCE="setup/env.sh"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL=./setup/env.sh
   SURVEY_TARGETFILE=env.sh.txt
   SURVEY_TARGET=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_ENVSH="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

SURVEY_SOURCE="/etc/redhat-release"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   LINUXFLAVOR=`cat $SURVEY_SOURCE`
fi

SURVEY_SOURCE="/etc/SuSE-release"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   LINUXFLAVOR=`cat $SURVEY_SOURCE`
fi

SURVEY_SOURCE="/proc/meminfo"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="Memory Info"
   SURVEY_TARGETFILE="meminfo.txt"
   SURVEY_TARGET="$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE"
   cp $SURVEY_SOURCE $SURVEY_TARGET
   SURVEY_NAV_MEMINFO="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

SURVEY_SOURCE="~/.businessobjects/clusterinfo.1400.properties"
if [ -s $SURVEY_SOURCE ]; then
echo "Collecting $SURVEY_SOURCE"
   SURVEY_TARGETLABEL="Cluster Info"
   SURVEY_TARGETFILE="clusterinfo.txt"
   SURVEY_TARGET="$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE"

   SURVEY_FILESIZE=`ls -s "$SURVEY_SOURCE" | awk '{print $1}'` 
   if [ $SURVEY_FILESIZE < 4 ]; then
   # the file is small enough to be valid   
   cp $SURVEY_SOURCE $SURVEY_TARGET
   else
   echo "$SURVEY_SOURCE is too large ( $SURVEY_FILESIZE bytes ) and appears to be corrupt.  This can prevent the web apps from starting.  Delete the file and restart the web app server (ex: tomcat)" > $SURVEY_TARGET
   fi
   SURVEY_NAV_CLUSTERINFO="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi


## End config file Collection ##
######################################

############################
## Networking details

SURVEY_TARGETLABEL="Network - Active Sockets"
SURVEY_TARGETFILE=netstat.txt
echo "Collecting $SURVEY_TARGETLABEL"
echo $SURVEY_NETWORKING_NETSTAT > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_NETWORKSOCKETS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_NETWORKING_NETSTAT=""

SURVEY_TARGETLABEL="Network - Statistics"
echo "Collecting $SURVEY_TARGETLABEL"
SURVEY_TARGETFILE=netstat-stats.txt
echo $SURVEY_NETWORKING_STATS > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_NETWORKSTATS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_NETWORKING_STATS=""

SURVEY_TARGETLABEL="Network - ifconfig"
echo "Collecting $SURVEY_TARGETLABEL"
SURVEY_TARGETFILE=ifconfig.txt
echo $SURVEY_NETWORKING_CONFIG > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_NETWORKCONFIG="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_NETWORKING_CONFIG=""

## End Networking details
############################

SURVEY_TARGETLABEL="Packages Installed"
SURVEY_TARGETFILE=rpmlist.txt
echo "Collecting $SURVEY_TARGETLABEL"
echo $SURVEY_OS_PACKAGELIST > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_PACKAGELIST="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_OS_PACKAGELIST=""

if [ $OS = 'aix4' ]; then
   SURVEY_TARGETLABEL="OS Patches Installed"
   SURVEY_TARGETFILE=patchlist.txt
   echo "Collecting $SURVEY_TARGETLABEL"
   echo $SURVEY_OS_PATCHES > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   SURVEY_NAV_PATCHES="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   SURVEY_OS_PATCHES=""

   SURVEY_TARGETLABEL="Installed C++"
   SURVEY_TARGETFILE=cplusplus.txt
   echo "Collecting $SURVEY_TARGETLABEL"
   echo $SURVEY_OS_CPLUSPLUS > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   SURVEY_NAV_CPLUSPLUS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   SURVEY_OS_CPLUSCPLUS=""

fi

#########################
## BEGIN File System Details ##

echo "##########################" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "## output of df command ##" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "##########################" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "" >> $SURVEY_OUTDIR/files/filesystem.txt
echo $SURVEY_FILESURVEY_SYSTEM_DF >> $SURVEY_OUTDIR/files/filesystem.txt
echo "" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "#############################" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "## output of mount command ##" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "#############################" >> $SURVEY_OUTDIR/files/filesystem.txt
echo "" >> $SURVEY_OUTDIR/files/filesystem.txt
echo $SURVEY_FILESURVEY_SYSTEM_MOUNTS >> $SURVEY_OUTDIR/files/filesystem.txt
SURVEY_NAV_SURVEY_FILESYSTEM="<li><a href=../files/filesystem.txt target=main>File system details</a>"

SURVEY_FILESURVEY_SYSTEM_DF=""
SURVEY_FILESURVEY_SYSTEM_MOUNTS=""

## END File System Details ##
#########################

########################
## Begin Environment Info
SURVEY_NAV_INSTALLDIRCONTENT=""
if [ $PRODUCT_IS_INSTALLED ]; then
   SURVEY_TARGETLABEL="Install Folder Contents"
   SURVEY_TARGETFILE=installdir-ls-l.txt
   echo "Collecting $SURVEY_TARGETLABEL"
   ls -la >> $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE 2>&1
   SURVEY_NAV_INSTALLDIRCONTENTS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

   if [ -d "enterprise_xi40/packages" ]; then
   SURVEY_TARGETLABEL="Failed dfos"
   SURVEY_TARGETFILE=dfoleftovers.txt
   echo "Collecting $SURVEY_TARGETLABEL"
   ls -l enterprise_xi40/packages/ >> $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE 2>&1
   SURVEY_NAV_FAILEDDFOS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   fi

fi

#SURVEY_TARGETLABEL="History"
#SURVEY_TARGETFILE=history.txt
#echo "Collecting command history"
#history > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE 2>&1
#SURVEY_NAV_HISTORY="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

SURVEY_TARGETLABEL="Installed Locales"
SURVEY_TARGETFILE=locales.txt
echo "Collecting $SURVEY_TARGETLABEL"
/usr/bin/locale -a >> $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE 2>&1
SURVEY_NAV_LOCALES="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

SURVEY_TARGETLABEL="Current Locales"
SURVEY_TARGETFILE=locale.txt
echo "Collecting $SURVEY_TARGETLABEL"
/usr/bin/locale >> $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE 2>&1
SURVEY_NAV_LOCALE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"


SURVEY_TARGETLABEL="GCC details"
SURVEY_TARGETFILE=gcc.txt
echo "Collecting $SURVEY_TARGETLABEL"
/usr/bin/gcc -v >> $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE 2>&1
SURVEY_NAV_GCC="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

SURVEY_TARGETLABEL="Process List"
echo "Collecting $SURVEY_TARGETLABEL"
SURVEY_TARGETFILE=processlist.txt
echo $SURVEY_DETAILS_RUNNING_PROCESSES > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_PROCESSLIST="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_DETAILS_RUNNING_PROCESSES=""

SURVEY_TARGETLABEL="Kernel Limits"
echo "Collecting $SURVEY_TARGETLABEL"
SURVEY_TARGETFILE=kernellimits.txt
echo $SURVEY_KERNEL_LIMITS > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_KERNELLIMITS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_KERNEL_LIMITS=""

SURVEY_TARGETLABEL="Kernel Usage"
echo "Collecting $SURVEY_TARGETLABEL"
SURVEY_TARGETFILE=kernelusage.txt
echo $SURVEY_KERNEL_USAGE > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_KERNELUSAGE="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
SURVEY_KERNEL_USAGE=""

SURVEY_TARGETLABEL="ulimits - pre env sourcing"
echo "Collecting $SURVEY_TARGETLABEL"
SURVEY_TARGETFILE=ulimits.txt
ulimit -a > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_ULIMITS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

if [ -x /usr/bin/nohup ]; then
SURVEY_MISC_NOHUP="<li><font color=#green>NOHUP CHECK - PASS: /usr/bin/nohup must be executable, and it is.</font>";
else
SURVEY_MISC_NOHUP="<li><font color=#red>NOHUP CHECK - FAIL: /usr/bin/nohup must be executable, it is not, please have your system admin correct this.</font>";
fi

SURVEY_TARGETLABEL="pre-sourcing env cmd"
SURVEY_TARGETFILE=presourc-env.txt
echo "Collecting $SURVEY_TARGETLABEL"
env > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
SURVEY_NAV_PRESOURCE_ENV="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

if [ -s setup/env.sh ]; then
   . ./setup/env.sh
   SURVEY_TARGETLABEL="post-sourcing env cmd"
   echo "Collecting $SURVEY_TARGETLABEL"
   SURVEY_TARGETFILE=postsourc-env.txt
   env > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   SURVEY_NAV_POSTSOURCE_ENV="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"

   SURVEY_TARGETLABEL="ulimits - post env sourcing"
   echo "Collecting $SURVEY_TARGETLABEL"
   SURVEY_TARGETFILE=ulimits-postenv.txt
   ulimit -a > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   SURVEY_NAV_ULIMITS_POSTENV="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

## End Environment Info
########################

###########################
## LDD tests - must follow the sourcing of the env.sh
if [ $BINDIR ]; then
   echo "Running some LDD tests against product binaries"
   #echo "x"$SURVEY_GENERAL_PRODUCT"x"

   SURVEY_TARGETLABEL="ldd tests"
   SURVEY_TARGETFILE=lddresults.txt
   SURVEY_NAV_LDDTESTS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   SURVEY_DESTFILE=$SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   echo "Any missing dependencies in this list is cause for concern" > $SURVEY_DESTFILE
   echo "" >> $SURVEY_DESTFILE

   for TESTFILE in $BINDIR/boe_cmsd $BINDIR/boe_crcached.bin $BINDIR/boe_crprocd.bin $BINDIR/boe_eventsd $BINDIR/boe_filesd $BINDIR/boe_jobcd $BINDIR/boe_jobsd $BINDIR/boe_regedit $BINDIR/boe_reposcan $BINDIR/regsvr $BINDIR32/regsvr $BINDIR32/ras/boe_crystalras $BINDIR32/ras/boe_crystalrasd.bin $BINDIR32/boe_regedit $BINDIR32/boe_sslconfig $BINDIR32/crpe/libcrpe32.so $BINDIR32/crpe/xvfb/Xvfb
   do
    if [ -s $TESTFILE ]; then
       echo "LDD TEST $TESTFILE"
       echo "################" >> $SURVEY_DESTFILE
       echo "ldd $TESTFILE" >> $SURVEY_DESTFILE
       ldd $TESTFILE >> $SURVEY_DESTFILE
       echo "" >> $SURVEY_DESTFILE
    else
       echo "" >> $SURVEY_DESTFILE
       echo "######################" >> $SURVEY_DESTFILE
       echo "$TESTFILE is not on this system" >> $SURVEY_DESTFILE
       echo "######################" >> $SURVEY_DESTFILE
       echo "" >> $SURVEY_DESTFILE
    fi
   done

   SURVEY_NAV_LDDTESTS="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

## END LDD tests
###########################

###############################
## Begin DB2 Readiness Check ##
echo "Begin DB2 Readiness Check"
SQL_RESERVED=". A ADD ADMIN AFTER AGGREGATE ALIAS ALL ALLOCATE ALSO ALTER ALWAYS ANALYSE ANALYZE AND ANY ARE ARRAY AS ASC ASENSITIVE ASSERTION ASSIGNMENT ASYMMETRIC AT ATOMIC ATTRIBUTE ATTRIBUTES AUDIT AUTHORIZATION AUTO_INCREMENT AVG AVG_ROW_LENGTH BACKUP BACKWARD BEFORE BEGIN BERNOULLI BETWEEN BIGINT BINARY BIT BIT_LENGTH BITVAR BLOB BOOL BOOLEAN BOTH BREADTH BREAK BROWSE BULK BY C CACHE CALL CALLED CARDINALITY CASCADE CASCADED CASE CAST CATALOG CATALOG_NAME CEIL CEILING CHAIN CHANGE CHAR CHAR_LENGTH CHARACTER CHARACTER_LENGTH CHARACTER_SET_CATALOG CHARACTER_SET_NAME CHARACTER_SET_SCHEMA CHARACTERISTICS CHARACTERS CHECK CHECKED CHECKPOINT CHECKSUM CLASS CLASS_ORIGIN CLOB CLOSE CLUSTER CLUSTERED COALESCE COBOL COLLATE COLLATION COLLATION_CATALOG COLLATION_NAME COLLATION_SCHEMA COLLECT COLUMN COLUMN_NAME COLUMNS COMMAND_FUNCTION COMMAND_FUNCTION_CODE COMMENT COMMIT COMMITTED COMPLETION COMPRESS COMPUTE CONDITION CONDITION_NUMBER CONNECT CONNECTION CONNECTION_NAME CONSTRAINT CONSTRAINT_CATALOG CONSTRAINT_NAME CONSTRAINT_SCHEMA CONSTRAINTS CONSTRUCTOR CONTAINS CONTAINSTABLE CONTINUE CONVERSION CONVERT COPY CORR CORRESPONDING COUNT COVAR_POP COVAR_SAMP CREATE CREATEDB CREATEROLE CREATEUSER CROSS CSV CUBE CUME_DIST CURRENT CURRENT_DATE CURRENT_DEFAULT_TRANSFORM_GROUP CURRENT_PATH CURRENT_ROLE CURRENT_TIME CURRENT_TIMESTAMP CURRENT_TRANSFORM_GROUP_FOR_TYPE CURRENT_USER CURSOR CURSOR_NAME CYCLE DATA DATABASE DATABASES DATE DATETIME DATETIME_INTERVAL_CODE DATETIME_INTERVAL_PRECISION DAY DAY_HOUR DAY_MICROSECOND DAY_MINUTE DAY_SECOND DAYOFMONTH DAYOFWEEK DAYOFYEAR DBCC DEALLOCATE DEC DECIMAL DECLARE DEFAULT DEFAULTS DEFERRABLE DEFERRED DEFINED DEFINER DEGREE DELAY_KEY_WRITE DELAYED DELETE DELIMITER DELIMITERS DENSE_RANK DENY DEPTH DEREF DERIVED DESC DESCRIBE DESCRIPTOR DESTROY DESTRUCTOR DETERMINISTIC DIAGNOSTICS DICTIONARY DISABLE DISCONNECT DISK DISPATCH DISTINCT DISTINCTROW DISTRIBUTED DIV DO DOMAIN DOUBLE DROP DUAL DUMMY DUMP DYNAMIC DYNAMIC_FUNCTION DYNAMIC_FUNCTION_CODE EACH ELEMENT ELSE ELSEIF ENABLE ENCLOSED ENCODING ENCRYPTED END END-EXEC "

SQL_RESERVED=$SQL_RESERVED"ENUM EQUALS ERRLVL ESCAPE ESCAPED EVERY EXCEPT EXCEPTION EXCLUDE EXCLUDING EXCLUSIVE EXEC EXECUTE EXISTING EXISTS EXIT EXP EXPLAIN EXTERNAL EXTRACT FALSE FETCH FIELDS FILE FILLFACTOR FILTER FINAL FIRST FLOAT FLOAT4 FLOAT8 FLOOR FLUSH FOLLOWING FOR FORCE FOREIGN FORTRAN FORWARD FOUND FREE FREETEXT FREETEXTTABLE FREEZE FROM FULL FULLTEXT FUNCTION FUSION G GENERAL GENERATED GET GLOBAL GO GOTO GRANT GRANTED GRANTS GREATEST GROUP GROUPING HANDLER HAVING HEADER HEAP HIERARCHY HIGH_PRIORITY HOLD HOLDLOCK HOST HOSTS HOUR HOUR_MICROSECOND HOUR_MINUTE HOUR_SECOND IDENTIFIED IDENTITY IDENTITY_INSERT IDENTITYCOL IF IGNORE ILIKE IMMEDIATE IMMUTABLE IMPLEMENTATION IMPLICIT IN INCLUDE INCLUDING INCREMENT INDEX INDICATOR INFILE INFIX INHERIT INHERITS INITIAL INITIALIZE INITIALLY INNER INOUT INPUT INSENSITIVE INSERT INSERT_ID INSTANCE INSTANTIABLE INSTEAD INT INT1 INT2 INT3 INT4 INT8 INTEGER INTERSECT INTERSECTION INTERVAL INTO INVOKER IS ISAM ISNULL ISOLATION ITERATE JOIN K KEY KEY_MEMBER KEY_TYPE KEYS KILL LANCOMPILER LANGUAGE LARGE LAST LAST_INSERT_ID LATERAL LEADING LEAST LEAVE LEFT LENGTH LESS LEVEL LIKE LIMIT LINENO LINES LISTEN LN LOAD LOCAL LOCALTIME LOCALTIMESTAMP LOCATION LOCATOR LOCK LOGIN LOGS LONG LONGBLOB LONGTEXT LOOP LOW_PRIORITY LOWER M MAP MATCH MATCHED MAX MAX_ROWS MAXEXTENTS MAXVALUE MEDIUMBLOB MEDIUMINT MEDIUMTEXT MEMBER MERGE MESSAGE_LENGTH MESSAGE_OCTET_LENGTH MESSAGE_TEXT METHOD MIDDLEINT MIN MIN_ROWS MINUS MINUTE MINUTE_MICROSECOND MINUTE_SECOND MINVALUE MLSLABEL MOD MODE MODIFIES MODIFY MODULE MONTH MONTHNAME MORE MOVE MULTISET MUMPS MYISAM NAME NAMES NATIONAL NATURAL NCHAR NCLOB NESTING NEW NEXT NO NO_WRITE_TO_BINLOG NOAUDIT NOCHECK NOCOMPRESS NOCREATEDB NOCREATEROLE NOCREATEUSER NOINHERIT NOLOGIN NONCLUSTERED NONE NORMALIZE NORMALIZED NOSUPERUSER NOT NOTHING NOTIFY NOTNULL NOWAIT NULL NULLABLE NULLIF NULLS NUMBER NUMERIC OBJECT OCTET_LENGTH OCTETS OF OFF OFFLINE OFFSET OFFSETS OIDS OLD ON ONLINE ONLY OPEN OPENDATA OPENQUERY"

SQL_RESERVED=$SQL_RESERVED" OPENROWSET OPENXML OPERATION OPERATOR OPTIMIZE OPTION OPTIONALLY OPTIONS OR ORDER ORDERING ORDINALITY OTHERS OUT OUTER OUTFILE OUTPUT OVER OVERLAPS OVERLAY OVERRIDING OWNER PACK_KEYS PAD PARAMETER PARAMETER_MODE PARAMETER_NAME PARAMETER_ORDINAL_POSITION PARAMETER_SPECIFIC_CATALOG PARAMETER_SPECIFIC_NAME PARAMETER_SPECIFIC_SCHEMA PARAMETERS PARTIAL PARTITION PASCAL PASSWORD PATH PCTFREE PERCENT PERCENT_RANK PERCENTILE_CONT PERCENTILE_DISC PLACING PLAN PLI POSITION POSTFIX POWER PRECEDING PRECISION PREFIX PREORDER PREPARE PREPARED PRESERVE PRIMARY PRINT PRIOR PRIVILEGES PROC PROCEDURAL PROCEDURE PROCESS PROCESSLIST PUBLIC PURGE QUOTE RAID0 RAISERROR RANGE RANK RAW READ READS READTEXT REAL RECHECK RECONFIGURE RECURSIVE REF REFERENCES REFERENCING REGEXP REGR_AVGX REGR_AVGY REGR_COUNT REGR_INTERCEPT REGR_R2 REGR_SLOPE REGR_SXX REGR_SXY REGR_SYY REINDEX RELATIVE RELEASE RELOAD RENAME REPEAT REPEATABLE REPLACE REPLICATION REQUIRE RESET RESIGNAL RESOURCE RESTART RESTORE RESTRICT RESULT RETURN RETURNED_CARDINALITY RETURNED_LENGTH RETURNED_OCTET_LENGTH RETURNED_SQLSTATE RETURNS REVOKE RIGHT RLIKE ROLE ROLLBACK ROLLUP ROUTINE ROUTINE_CATALOG ROUTINE_NAME ROUTINE_SCHEMA ROW ROW_COUNT ROW_NUMBER ROWCOUNT ROWGUIDCOL ROWID ROWNUM ROWS RULE SAVE SAVEPOINT SCALE SCHEMA SCHEMA_NAME SCHEMAS SCOPE SCOPE_CATALOG SCOPE_NAME SCOPE_SCHEMA SCROLL SEARCH SECOND SECOND_MICROSECOND SECTION SECURITY SELECT SELF SENSITIVE SEPARATOR SEQUENCE SERIALIZABLE SERVER_NAME SESSION SESSION_USER SET SETOF SETS SETUSER SHARE SHOW SHUTDOWN SIGNAL SIMILAR SIMPLE SIZE SMALLINT SOME SONAME SOURCE SPACE SPATIAL SPECIFIC SPECIFIC_NAME SPECIFICTYPE SQL SQL_BIG_RESULT SQL_BIG_SELECTS SQL_BIG_TABLES SQL_CALC_FOUND_ROWS SQL_LOG_OFF SQL_LOG_UPDATE SQL_LOW_PRIORITY_UPDATES SQL_SELECT_LIMIT SQL_SMALL_RESULT SQL_WARNINGS SQLCA SQLCODE SQLERROR SQLEXCEPTION SQLSTATE SQLWARNING SQRT SSL STABLE START STARTING STATE STATEMENT STATIC STATISTICS STATUS STDDEV_POP STDDEV_SAMP STDIN STDOUT STORAGE STRAIGHT_JOIN STRICT STRING"

SQL_RESERVED=$SQL_RESERVED" STRUCTURE STYLE SUBCLASS_ORIGIN SUBLIST SUBMULTISET SUBSTRING SUCCESSFUL SUM SUPERUSER SYMMETRIC SYNONYM SYSDATE SYSID SYSTEM SYSTEM_USER TABLE TABLE_NAME TABLES TABLESAMPLE TABLESPACE TEMP TEMPLATE TEMPORARY TERMINATE TERMINATED TEXT TEXTSIZE THAN THEN TIES TIME TIMESTAMP TIMEZONE_HOUR TIMEZONE_MINUTE TINYBLOB TINYINT TINYTEXT TO TOAST TOP TOP_LEVEL_COUNT TRAILING TRAN TRANSACTION TRANSACTION_ACTIVE TRANSACTIONS_COMMITTED TRANSACTIONS_ROLLED_BACK TRANSFORM TRANSFORMS TRANSLATE TRANSLATION TREAT TRIGGER TRIGGER_CATALOG TRIGGER_NAME TRIGGER_SCHEMA TRIM TRUE TRUNCATE TRUSTED TSEQUAL TYPE UESCAPE UID UNBOUNDED UNCOMMITTED UNDER UNDO UNENCRYPTED UNION UNIQUE UNKNOWN UNLISTEN UNLOCK UNNAMED UNNEST UNSIGNED UNTIL UPDATE UPDATETEXT UPPER USAGE USE USER USER_DEFINED_TYPE_CATALOG USER_DEFINED_TYPE_CODE USER_DEFINED_TYPE_NAME USER_DEFINED_TYPE_SCHEMA USING UTC_DATE UTC_TIME UTC_TIMESTAMP VACUUM VALID VALIDATE VALIDATOR VALUE VALUES VAR_POP VAR_SAMP VARBINARY VARCHAR VARCHAR2 VARCHARACTER VARIABLE VARIABLES VARYING VERBOSE VIEW VOLATILE WAITFOR WHEN WHENEVER WHERE WHILE WIDTH_BUCKET WINDOW WITH WITHIN WITHOUT WORK WRITE WRITETEXT X509 XOR YEAR YEAR_MONTH ZEROFILL ZONE "

SURVEY_OUTFILE=$SURVEY_OUTDIR/files/db2.html
echo "Testing the system for DB2 readiness"
echo "packaged DB2 readiness):<br>"  > $SURVEY_OUTFILE
echo "(The packaged db2 database used for the cms has some special requirements, these are what the following test check for.)<br>"  >> $SURVEY_OUTFILE
#Get the userid that I am being run as
# Moved to the top ## SURVEY_UID=`id -u`
echo "UID is $SURVEY_UID <br>"  >> $SURVEY_OUTFILE
#Get the username
# Moved to the top ## SURVEY_UNAME=`id -un`
echo "Username is $SURVEY_UNAME <br>"  >> $SURVEY_OUTFILE
#Get the primary group
# Moved to the top ## SURVEY_PGID=`id -g`
echo "Primary Group ID is $SURVEY_PGID <br>" >> $SURVEY_OUTFILE
#Get the primary group name
# Moved to the top ## SURVEY_PGNAME=`id -gn`
echo "Primary Group Name is $SURVEY_PGNAME <br>" >> $SURVEY_OUTFILE
echo "<HR><BR>" >> $SURVEY_OUTFILE

#Is the userid the same as the user name?
if [ $SURVEY_UID = $SURVEY_UNAME ]; then
   echo "<li><font color=#red>FAIL: The Userid - $SURVEY_UID - appears to equal the Username - $SURVEY_UNAME - suggesting that it failed to resolve, please investigate and resolve.</font><br>" >> $SURVEY_OUTFILE
else echo "<li><font color=#green>PASS: Username and userid do not match</font><br>" >> $SURVEY_OUTFILE
   fi

#Is the gid the same as the group name?

if [ $SURVEY_PGID = $SURVEY_PGNAME ]; then
   echo "<li><font color=#red>FAIL: The group id - $SURVEY_PGID - appears to equal the Group Name - $SURVEY_PGNAME - suggesting that it failed to resolve, please investigate and resolve.</font>" >> $SURVEY_OUTFILE
else echo "<li><font color=#green>PASS: Group name and groupid do not match</font><br>" >> $SURVEY_OUTFILE
   fi

#is the group name restricted (guests, admins, users, and local)
BADGROUPS=". USERS ADMINS GUESTS LOCAL ";
groupnametest=`echo $BADGROUPS | tr A-Z a-z | sed "s/^.* $SURVEY_PGNAME .*$/FAIL/g"`
testsize=`echo $groupnametest | wc -w`
if [ $testsize -eq 1 ]; then
   echo "<li><font color=#red>FAIL: Groupname, currently $SURVEY_PGNAME, is in violation, cannot be: USERS ADMINS GUESTS or LOCAL</font>" >> $SURVEY_OUTFILE
else echo "<li><font color=#green>PASS: Groupname is not one of the following: USERS ADMINS GUESTS PUBLIC or LOCAL</font>" >> $SURVEY_OUTFILE
fi

#Does the user name start with ibm sys sql or a number?
#usernametest=`echo $SURVEY_UNAME|awk '{print substr($0,0,3)}'|grep -v ibm|grep -v sys|grep -v sql|wc -l`
echo "Testing for ibm sys sql at start of the username (would be bad)"
#usernametest=`echo $SURVEY_UNAME|sed "s/^[is][byq][msl].*/FAILED/"`
usernametest=`echo $SURVEY_UNAME|sed "s/^(ibm|sql|sys).*/FAILED/"`
#echo "SURVEY_UNAME - "$SURVEY_UNAME
#echo "usernametest - "$usernametest
if [ $usernametest = 'FAILED' ]; then
   echo "<li><font color=#red>FAIL: Username, currently $SURVEY_UNAME, cannot begin with the strings: ibm sys sql</font>" >> $SURVEY_OUTFILE
fi

echo "Testing for a number at start of the username (would be bad)"
usernametest=`echo $SURVEY_UNAME|sed "s/^[0-9].*/FAILED/"`
if [ $usernametest = 'FAILED' ]; then
   echo "<li><font color=#red>FAIL: Username, currently $SURVEY_UNAME, cannot begin with a number.</font>" >> $SURVEY_OUTFILE
else 
   echo "<li><font color=#green>PASS: Username does not begin with a number</font>"  >> $SURVEY_OUTFILE
fi

#User ID can only include lowercase letters (a-z), numbers (0-9), and the underscore character ( _ )

echo "Testing for non alphanumerics+_ in username"
usernametest=`echo "X"$SURVEY_UNAME"X" |sed "s/[a-z0-9_]//g"`
if [ $usernametest != "XX" ]; then
   echo "<li><font color=#red>FAIL: Username, currently $SURVEY_UNAME, must only contain lower case letters, numbers or the underscore (_).</font>" >> $SURVEY_OUTFILE
else 
   echo "<li><font color=#green>PASS: Username only contains lowercase characters, numbers or underscore</font>" >> $SURVEY_OUTFILE
fi

#User ID cannot be a DB2 reserved word (USERS, ADMINS, GUESTS, PUBLIC, or LOCAL), or an SQL reserved word
usernametest=`echo $SQL_RESERVED | tr A-Z a-z | sed "s/^.* $SURVEY_UNAME .*$/FAIL/"`
testsize=`echo $usernametest | wc -w`
if [ $testsize -eq 1 ]; then
   echo "<li><font color=#red>FAIL: Username, currently $SURVEY_UNAME, is a SQL Reserved word</font>" >> $SURVEY_OUTFILE
else echo "<li><font color=#green>PASS: Username is not an SQL reserved word or one of the following: USERS ADMINS GUESTS PUBLIC or LOCAL</font>" >> $SURVEY_OUTFILE
fi

# check for rights on the /tmp folder
tmptest=`mount|grep /tmp|grep noexec | wc -l`
tmptestout=`mount|grep /tmp|grep noexec`
if [ $tmptest -eq 1 ]; then
   echo "<li><font color=#red>FAIL: /tmp is mounted with noexec rights</font>" >> $SURVEY_OUTFILE
   echo "   --- $tmptestout <br>" >> $SURVEY_OUTFILE
else
   echo "<li><font color=#green>PASS: /tmp is not mounted with noexec rights</font>" >> $SURVEY_OUTFILE
fi

# check the ulimits, db2 likes a very high nofiles value, unlimited if possible
# get the default value, then attempt to set it to unlimited and confirm it worked.
defulimit=`ulimit -n`
if [ $defulimit = "unlimited" ]; then
   echo "<li><font color=#green>PASS: ulimit is set to unlimited for nofile (open files)</font>" >> $SURVEY_OUTFILE
else
   if [ $defulimit -gt 65535 ]; then
      echo "<li><font color=#green>PASS: ulimit nofile (open files) setting of $defulimit is sufficient per IBM</font>" >> $SURVEY_OUTFILE
   else
      ulimit -n 65536 2>/dev/null
      hulimit=`ulimit -H -n`
      newulimit=`ulimit -n`
      if [ $newulimit -eq 65536 ]; then
         echo "<li><font color=#green>PASS: ulimit nofile setting was successfully set to 65536</font>" >> $SURVEY_OUTFILE
      else
         ustatus="Fail"
         ulevel=$hulimit
         if [ $hulimit -gt 65535 ]; then
            ustatus="Pass"
         fi
         if [ $hulimit = "unlimited" ]; then
            ustatus="Pass"
         fi
         if [ $ustatus = "Fail" ]; then
            echo "<li><font color=#red>FAIL: ulimit nofile (open files) setting of $defulimit is too low (less than 65536)</font>" >> $SURVEY_OUTFILE
         fi
         if [ $ustatus = "Pass" ]; then
            echo "<li><font color=#green>Pass: ulimit nofile (open files) is set to $ulevel</font>" >> $SURVEY_OUTFILE
         fi
      fi
   fi
fi


# Kernel Parameter checking
# The following param tests are to be done:
# max seg size => 1048576
# max number of arrays => 1024
# max quese system wide => 1024
# max size of message => 65536
# default max size of queue => 65536

# get the above values
if [ $OS = "linux" ]; then
   SHMMAX=`ipcs -l | grep "max seg size"|awk -F= '{print $2}'`
   SEMMNI=`ipcs -l | grep "max number of arrays" | awk -F= '{print $2}'`
   MSGMNI=`ipcs -l | grep "max queues system wide" | awk -F= '{print $2}'`
   MSGMAX=`ipcs -l | grep "max size of message" | awk -F= '{print $2}'`
   MSGMNB=`ipcs -l | grep "default max size of queue" | awk -F= '{print $2}'`

   #echo "SHMMAX=$SHMMAX\n"
   #echo "SEMMNI=$SEMMNI\n"
   #echo "MSGMNI=$MSGMNI\n"
   #echo "MSGMAX=$MSGMAX\n"
   #echo "MSGMNB=$MSGMNB\n"
   kstatus="PASS";
   echo "<br>" >> $SURVEY_OUTFILE
   echo "KERNEL SETTING TESTS for DB2<br>" >> $SURVEY_OUTFILE
   echo "<br>" >> $SURVEY_OUTFILE

   if [ $SHMMAX -lt 1048575 ]; then
      kstatus="FAIL"
      echo "<li><font color=#red>FAIL: SHMMAX / max seg size (kbytes) is $SHMMAX, which is below the minimum of 1048576</font>" >> $SURVEY_OUTFILE
   else
      echo "<li><font color=#green>PASS: SHMMAX / max seg size (kbytes) is $SHMMAX, which is at or above the minimum of 1048576</font>" >> $SURVEY_OUTFILE
   
   fi

   if [ $SEMMNI -lt 1024 ]; then
      kstatus="FAIL"
      echo "<li><font color=#red>FAIL: SEMMNI / max number of arrays is $SEMMNI, which is less than the minimum of 1024</font>" >> $SURVEY_OUTFILE
   else
      echo "<li><font color=#green>PASS: SEMMNI / max number of arrays is $SEMMNI, which is at or above the minimum of 1024</font>" >> $SURVEY_OUTFILE
   fi

   if [ $MSGMNI -lt 1024 ]; then
      kstatus="FAIL"
      echo "<li><font color=#red>FAIL: MSGMNI / max queues system wide is $MSGMNI, which is less than the minimum of 1024</font>" >> $SURVEY_OUTFILE
   else
      echo "<li><font color=#green>PASS: MSGMNI / max queues system wide is $MSGMNI, which is at or above the minimum of 1024</font>" >> $SURVEY_OUTFILE
   fi

   if [ $MSGMAX -lt 65536 ]; then
      kstatus="FAIL"
      echo "<li><font color=#red>FAIL: MSGMAX / max size of message (bytes) is $MSGMAX, which is less than the minimum of 65536</font>" >> $SURVEY_OUTFILE
   else
      echo "<li><font color=#green>PASS: MSGMAX / max size of message (bytes) is $MSGMAX, which is at or above the minimum of 65536</font>" >> $SURVEY_OUTFILE
   fi

   if [ $MSGMNB -lt 65536 ]; then
   kstatus="FAIL"
      echo "<li><font color=#red>FAIL: MSGMNB / default max size of queue (bytes) is $MSGMNB, which is less than the minimum of 65536</font>" >> $SURVEY_OUTFILE
   else
      echo "<li><font color=#green>PASS: MSGMNB / default max size of queue (bytes) is $MSGMNB, which is at or above the minimum of 65536</font>" >> $SURVEY_OUTFILE
   fi

   if [ $kstatus = "FAIL" ]; then
   echo "<br>" >> $SURVEY_OUTFILE
   echo "Before you can use the provided db2 database for your system you will need to correct the above kernel parameters marked as FAIL<br>" >> $SURVEY_OUTFILE
   echo "<br>" >> $SURVEY_OUTFILE
   fi

fi

echo "<br>" >> $SURVEY_OUTFILE
echo "Verbose output of commands:<br>" >> $SURVEY_OUTFILE
echo "output of 'id': "`id`"<br>" >> $SURVEY_OUTFILE
echo "<br>" >> $SURVEY_OUTFILE
echo "End XI4 System Readiness tests<br>" >> $SURVEY_OUTFILE
echo "Please note, this does not imply that there will be no problems, only that some known gotchas have been tested.<br>" >> $SURVEY_OUTFILE
echo "<hr><br>" >> $SURVEY_OUTFILE

SURVEY_NAV_DB2READINESS="<li><a href=../files/db2.html target=main>DB2 Readiness</a>"

## End DB2 Readiness Check ##
##############################

if [ $OS = "aix4" ]; then
   if [ -x /usr/bin/lparstat ]; then
      SURVEY_DETAILS_LPARSTAT=`lparstat -i | awk 'sub("$", "<br>")'`
      SURVEY_TARGETLABEL="lparstat -i"
      echo "Collecting $SURVEY_TARGETLABEL"
      SURVEY_TARGETFILE=lparstat.html
      echo $SURVEY_DETAILS_LPARSTAT > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
      SURVEY_NAV_LPARSTAT="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
   fi
fi

################################
## Post ENV.sh sourcing

if [ -s ./setup/env.sh ]; then
   . ./setup/env.sh
   SURVEY_DETAILS_ENV_POST_ENVSH=`env | sed "s/$/\<br\>/"`
   SURVEY_TARGETLABEL="\"set\" command - POST env.sh"
   echo "Collecting $SURVEY_TARGETLABEL"
   SURVEY_TARGETFILE=postsource-env.html
   echo $SURVEY_DETAILS_ENV_POST_ENVSH > $SURVEY_OUTDIR/files/$SURVEY_TARGETFILE
   SURVEY_NAV_POSTSURVEY_SOURCEENV="<li><a href=../files/$SURVEY_TARGETFILE target=main>$SURVEY_TARGETLABEL</a>"
fi

## End POST ENV.SH Sourcing
################################

###################################################
###### Final steps, create the html elements ######
echo "<html>" > $SURVEY_OUTDIR/index.html
echo "<head>" >> $SURVEY_OUTDIR/index.html
echo "<title>$HOSTNAME details</title>" >> $SURVEY_OUTDIR/index.html
echo "</head>" >> $SURVEY_OUTDIR/index.html
echo "<frameset rows=\"100,*\" frameborder=\"1\" border=\"0\" framespacing=\"0\">" >> $SURVEY_OUTDIR/index.html
echo "  <frame name=\"top\" src=\"content/survey.html\">" >> $SURVEY_OUTDIR/index.html
echo "<frameset cols=\"200,*\" frameborder=\"1\" border=\"0\" framespacing=\"0\">" >> $SURVEY_OUTDIR/index.html
echo "	<frame name=\"left\" src=\"content/nav.html\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"auto\" >" >> $SURVEY_OUTDIR/index.html
echo "	<frame name=\"main\" src=\"content/main.html\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"auto\" >" >> $SURVEY_OUTDIR/index.html
echo "</frameset>" >> $SURVEY_OUTDIR/index.html
echo "</frameset>" >> $SURVEY_OUTDIR/index.html
echo "</html>" >> $SURVEY_OUTDIR/index.html

echo "<html>" > $SURVEY_OUTDIR/content/main.html
echo "<head>" >> $SURVEY_OUTDIR/content/main.html
echo "</head>" >> $SURVEY_OUTDIR/content/main.html
echo "<body>" >> $SURVEY_OUTDIR/content/main.html
#fill this area in with general system info, like OS brand and version, cpu details, memory amount, hostname, fqdn, and so on.  A quick overview of the host.
echo "<table align=center width=100%>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td colspan=2 align=center>General Environment Information</td></tr>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td width=150>Hostname:</td><td>"`hostname`"</td></tr>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td >System Uptime</td><td>$SURVEY_SYSTEM_UPTIME</td></tr>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td >Operating System</td><td>$UNAME</td></tr>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td>CPU Details</td><td>$SURVEY_CPU_COUNT x $SURVEY_CPU_INFO</td></tr>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td>Installed RAM</td><td>$SURVEY_MEMORY_INSTALLED</td></tr>" >> $SURVEY_OUTDIR/content/main.html
echo "<tr><td>Locale</td><td>$SURVEY_MAIN_LOCALE</td></tr>" >> $SURVEY_OUTDIR/content/main.html
if [ $OS = 'linux' ]; then 
   echo "<tr><td>Linux Release</td><td>Release File contents: $LINUXFLAVOR</td></tr>" >> $SURVEY_OUTDIR/content/main.html
   if [ -s $SURVEY_OUTDIR/files/CENTOS.txt ]; then
      echo $SURVEY_CENTOS_ALERT >> $SURVEY_OUTDIR/content/main.html
   fi
fi
if [ $OS = 'aix4' ]; then
   echo "<tr><td>AIX OSLEVEL</td><td>"`oslevel -s`"</td></tr>" >> $SURVEY_OUTDIR/content/main.html
fi

if [ $SURVEY_DETAILS_OPENFILES_COUNT != 'unavailable' ]; then
echo "<tr><td>Open Files</td><td>This user has "$SURVEY_DETAILS_OPENFILES_COUNT" files currently open of (ulimit -Hn) `ulimit -Hn` allowed</td></tr>" >> $SURVEY_OUTDIR/content/main.html
fi

echo "<tr><td>Running Processes</td><td>This user has "$SURVEY_DETAILS_RUNNING_PROCESSES_COUNT" processes currently running out of (ulimit -u) ( "$SURVEY_MAX_PROC" ) allowed</td></tr>" >> $SURVEY_OUTDIR/content/main.html
if [ $SURVEY_CLUSTERFILECOUNT -gt 1 ]; then
   echo "<tr><td valign=top>Cluster Files</td><td>This user has "$SURVEY_CLUSTERFILECOUNT" clusters defined for multiple product versions.  There should only be 1 per user.  Please check the .businessobjects folder in the users home directory.</td></tr>" >> $SURVEY_OUTDIR/content/main.html
fi
echo "</table>" >> $SURVEY_OUTDIR/content/main.html
echo "</body>" >> $SURVEY_OUTDIR/content/main.html
echo "</html>" >> $SURVEY_OUTDIR/content/main.html

echo "<html>" > $SURVEY_OUTDIR/content/survey.html
echo "<head>$SURVEY_STYLE</head>" >> $SURVEY_OUTDIR/content/survey.html
echo "<body>" >> $SURVEY_OUTDIR/content/survey.html
echo "<table align=center width=100% >" >> $SURVEY_OUTDIR/content/survey.html
echo "<tr><td align=left>Survey Script Details<br>Version: $VER<br><a href=\"http://service.sap.com/sap/support/notes/1681036\" target=_blank>Link to latest version</a></td><td valign=top>" >> $SURVEY_OUTDIR/content/survey.html
echo "   <table>" >> $SURVEY_OUTDIR/content/survey.html
echo "      <tr><td align=right><b>Run Date</b></td><td align=center>"`date`"</td></tr>" >> $SURVEY_OUTDIR/content/survey.html
echo "      <tr><td align=right><b>Run From</b></td><td align=center>"`ls -ld $PWD`"</td></tr>" >> $SURVEY_OUTDIR/content/survey.html
echo "      <tr><td align=right><b>Run by user</b></td><td align=center>"`id`"</td></tr>" >> $SURVEY_OUTDIR/content/survey.html
echo "   </table>" >> $SURVEY_OUTDIR/content/survey.html
echo "</td></tr>" >> $SURVEY_OUTDIR/content/survey.html
echo "</table>" >> $SURVEY_OUTDIR/content/survey.html
echo "</body>" >> $SURVEY_OUTDIR/content/survey.html
echo "</html>" >> $SURVEY_OUTDIR/content/survey.html

SURVEY_MISC_CONTENT="The following information is miscellaneous details about the host that dont justify a category of their own. Where possible pass or fail is identified by green or red text.<br>"
SURVEY_MISC_CONTENT=$SURVEY_MISC_CONTENT$SURVEY_MISC_NOHUP
SURVEY_MISC_CONTENT=$SURVEY_MISC_CONTENT$SURVEY_MISC_LIBEXPAT32
SURVEY_MISC_CONTENT=$SURVEY_MISC_CONTENT$SURVEY_MISC_LIBEXPAT64

echo $SURVEY_MISC_CONTENT > $SURVEY_OUTDIR/files/misc.html
SURVEY_NAV_MISC="<li><a href=../files/misc.html target=main>Miscellaneous Info</a>"

NAV_AIXSPECIFIC=""
if [ $OS = "aix4" ]; then
NAV_AIXSPECIFIC=$NAV_AIXSPECIFIC$SURVEY_NAV_LPARSTAT
fi

SURVEY_NAV=$SURVEY_OUTDIR/content/nav.html

SURVEY_NAV_GROUP_HOSTINFO="<hr>Host Information<br>"`hostname`"<hr>"
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO"<li><a href=main.html target=main>Host Specs</a>"
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_NETWORKCONFIG
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_NETWORKSOCKETS
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_NETWORKSTATS
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_HOSTSFILE
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_RESOLVFILE
if [ $OS = 'linux' ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_NSSWITCHFILE; fi
if [ $OS = 'sunos5' ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_NSSWITCHFILE; fi
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_MEMINFO
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$NAV_AIXSPECIFIC
#SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_HISTORY
if [ -n "${SURVEY_NAV_BI4CLUSTERFILE}" ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_BI4CLUSTERFILE; fi
if [ -n "${SURVEY_NAV_XI31CLUSTERFILE}" ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_XI31CLUSTERFILE; fi
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_DB2READINESS
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_SURVEY_FILESYSTEM
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_PROCESSLIST
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_KERNELUSAGE
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_KERNELLIMITS
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_ULIMITS
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_LOCALE
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_LOCALES
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_PACKAGELIST
if [ $OS = 'aix4' ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_PATCHES; fi
if [ $OS = 'aix4' ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_CPLUSPLUS; fi
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_GCC
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_PROFILE
if [ $SURVEY_ORACLE_TEST = '1' ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_ORACLE; fi
if [ $SURVEY_ORACLE32_TEST = '1' ]; then SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_ORACLE32; fi
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_BASH_PROFILE
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_MISC
SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_PRESOURCE_ENV

if [ $PRODUCT_IS_INSTALLED = 1 ]; then
   SURVEY_NAV_GROUP_PRODUCTINFO="<br><br><hr>Product Information<br>Found: $SURVEY_GENERAL_PRODUCT<hr><br>"
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_INVENTORY
   if [ $SURVEY_GENERAL_PRODUCT = 'BI4' ] ; then SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_SLDFILES; fi
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_INSTALLLOGS
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_WDEPLOYLOGS
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_WDEPLOYCONFS
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_INSTALLDIRCONTENTS
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_FAILEDDFOS
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_CCMCONFIG
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_SERVERXML
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_CATALINASH
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_SETENVSH
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_BOBJENVSH
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_ENVSH
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_ULIMITS_POSTENV
   #if [ $COREFILECOUNT -gt 0 ]; then SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_COREFILES; fi
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_LDDTESTS
   SURVEY_NAV_GROUP_HOSTINFO=$SURVEY_NAV_GROUP_HOSTINFO$SURVEY_NAV_POSTSOURCE_ENV
   SURVEY_NAV_GROUP_PRODUCTINFO=$SURVEY_NAV_GROUP_PRODUCTINFO$SURVEY_NAV_CLUSTERINFO
else
   SURVEY_NAV_GROUP_PRODUCTINFO="<br><hr>BOE Product not found<br>where script was run<hr>"
fi

echo "<html>" > $SURVEY_NAV
echo "<head>" >> $SURVEY_NAV
echo "</head>" >> $SURVEY_NAV
echo "<body>" >> $SURVEY_NAV
echo $SURVEY_NAV_GROUP_HOSTINFO >> $SURVEY_NAV
echo $SURVEY_NAV_GROUP_PRODUCTINFO >> $SURVEY_NAV
echo "</body>" >> $SURVEY_NAV
echo "</html>" >> $SURVEY_NAV

######################################
# if done with editing the script, 
# remark this next line out
#exit
######################################

SURVEY_FINAL_OUTPUT=${SURVEY_OUTDIR}.tar
tar -cf $SURVEY_FINAL_OUTPUT $SURVEY_OUTDIR
gzip $SURVEY_FINAL_OUTPUT
SURVEY_FINAL_OUTPUT=${SURVEY_FINAL_OUTPUT}.gz
rm -rf $SURVEY_OUTDIR
clear

SURVEY_FILESIZE=`ls -s ${SURVEY_FINAL_OUTPUT}|awk '{print $1}'`
echo "################################"
echo "Thank you for running this script.  There is one final step."
echo "Please send the file ${SURVEY_FINAL_OUTPUT} to support."
if [ $SURVEY_FILESIZE -gt 4096 ]; then
   echo "Because the file exceeds the maximum allowed for email and case attachment"
   echo "it will need to be sent via SAPMATS.  If not already provided please request"
   echo "a SAPMATS link from your support engineer."
else 
   echo "Please attach this file to your support ticket."
fi
